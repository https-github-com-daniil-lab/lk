import PropTypes from "prop-types";
import React from "react";
import styles from "./burger-ingredient.module.css";

import {
  Counter,
  CurrencyIcon,
} from "@ya.praktikum/react-developer-burger-ui-components";

import { ingredientPropType } from "../../utils/prop-types";

const BurgerIngredient = ({ ingredientData, count, onClick }) => {
  const { image, price, name } = ingredientData;

  const handleClick = () => {
    onClick(ingredientData);
  };

  return (
    <article className={styles.article} onClick={handleClick}>
      {count && <Counter count={count} />}
      <img className={styles.img} src={image} alt="картинка ингредиента." />
      <div className={`${styles.cost} mt-2 mb-2`}>
        <p className="text text_type_digits-default mr-2">{price}</p>
        <CurrencyIcon />
      </div>
      <p className={`text text_type_main-default ${styles.text}`}>{name}</p>
    </article>
  );
};

BurgerIngredient.propTypes = {
  ingredientData: ingredientPropType,
  count: PropTypes.number,
  onClick: PropTypes.func,
};

//export default BurgerIngredient;
export default React.memo(BurgerIngredient);
