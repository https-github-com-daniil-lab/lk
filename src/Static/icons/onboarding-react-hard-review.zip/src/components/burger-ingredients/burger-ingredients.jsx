import React from "react";
import PropTypes from "prop-types";
import { Tab } from "@ya.praktikum/react-developer-burger-ui-components";
import IngredientsCategory from "../ingredients-category/ingredients-category";
import Modal from "../modal/modal";

import styles from "./burger-ingredients.module.css";
import { ingredientPropType } from "../../utils/prop-types";

const BurgerIngredients = ({ ingredients }) => {
  const [currentTab, setCurrentTab] = React.useState("buns");
  const [ingredientInModal, setIngredientInModal] = React.useState(null);
  const closeIngredientModal = () => setIngredientInModal(null);

  const onTabClick = (tab) => {
    setCurrentTab(tab);
    const element = document.getElementById(tab);
    if (element) element.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <section className={styles.burger_ingredients}>
        <nav>
          <ul className={styles.menu}>
            <Tab
              value="buns"
              active={currentTab === "buns"}
              onClick={onTabClick}
            >
              Булки
            </Tab>
            <Tab
              value="mains"
              active={currentTab === "mains"}
              onClick={onTabClick}
            >
              Начинки
            </Tab>
            <Tab
              value="sauces"
              active={currentTab === "sauces"}
              onClick={onTabClick}
            >
              Соусы
            </Tab>
          </ul>
        </nav>
        <div className={styles.content}>
          <IngredientsCategory
            title="Булки"
            titleId="buns"
            /*
              Можно лучше: здесь и далее, подготовку данных для отображения лучше описать до jsx
              Например так: 
                const buns = useMemo(
                  () => ingredients.filter((item) => item.type === "bun"),
                  [ingredients]
                );
             */ 
            ingredients={ingredients.filter((item) => item.type === "bun")}
            onIngredientClick={setIngredientInModal}
          />
          <IngredientsCategory
            title="Начинки"
            titleId="mains"
            ingredients={ingredients.filter((item) => item.type === "main")}
            onIngredientClick={setIngredientInModal}
          />
          <IngredientsCategory
            title="Соусы"
            titleId="sauces"
            ingredients={ingredients.filter((item) => item.type === "sauce")}
            onIngredientClick={setIngredientInModal}
          />
        </div>
      </section>
      {ingredientInModal && (
        <Modal
          onClose={closeIngredientModal}
          ingredientInModal={ingredientInModal}
          title="Детали ингредиента"
        />
      )}
    </>
  );
};

BurgerIngredients.propTypes = {
  ingredients: PropTypes.arrayOf(ingredientPropType),
};

export default BurgerIngredients;
