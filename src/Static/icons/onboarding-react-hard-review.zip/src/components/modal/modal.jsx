import React from "react";
import PropTypes from "prop-types";
import styles from "./modal.module.css";
import { ModalOverlay } from "../modal-overlay/modal-overlay";
import { CloseIcon } from "@ya.praktikum/react-developer-burger-ui-components";
import OrderDetails from "../order-details/order-details";
import IngredientDetails from "../ingredient-details/ingredient-details";

const Modal = ({ ingredientInModal, type, title, onClose, children }) => {
  React.useEffect(() => {
    const handleEsc = (e) => {
      e.key === "Escape" && onClose();
    };

    document.addEventListener("keydown", handleEsc);
    /*
    Надо исправить:
      Обработчик закрытия попапа должен добавляться при открытии попапа и удаляться при закрытии. Сейчас обработчик не будет удаляться при закрытии попапа т.к. из хука useEffect нужно возвращать колбэк отписки. Должно быть примерно так:

      ```
        useEffect(() => {
          const handleESCclose = () => {............} //обработчик события
          document.addEventListener("keydown", handleESCclose); //навешиваем обработчик
          
          //возвращаем колбэк отписки, который  будет вызван при размонтировании компонента
            return () => document.removeEventListener("keydown", handleESCclose)                                                                                               
        }, [onClose])
      ```
          */
  }, [onClose]);

  /*
    Надо исправить: для отображения модального окна на странице следует использовать портал
    React, что бы уменьшить количество проблем с наложением
    https://ru.reactjs.org/docs/portals.html
  */
  return (
    <>
      <div className={styles.modal}>
        <div className={styles.header}>
          <h3 className={`${styles.title} text text_type_main-large`}>
            {title}
          </h3>
          <button className={styles.button} type="button">
            <CloseIcon type="primary" onClick={onClose} />
          </button>
        </div>
        <div className={styles.content}>
          {/* Надо исправить: содержимое попапа должно передаваться в Modal
          как пропс children https://ru.reactjs.org/docs/composition-vs-inheritance.html
          Иначе компонент Modal сложно переиспользовать к другим соджержимым */}
          {type === "order" ? (
            <OrderDetails orderNumber="034536" />
          ) : (
            <IngredientDetails ingredientData={ingredientInModal} />
          )}
        </div>
      </div>
      <ModalOverlay onClick={onClose} />
    </>
  );
};

Modal.propTypes = {
  title: PropTypes.string,
  onClose: PropTypes.func,
  children: PropTypes.node,
  type: PropTypes.string,
};

export default Modal;
