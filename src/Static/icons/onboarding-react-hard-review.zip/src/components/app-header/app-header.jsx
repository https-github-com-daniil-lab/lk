import styles from "./app-header.module.css";
import {
  BurgerIcon,
  ListIcon,
  ProfileIcon,
  Logo,
} from "@ya.praktikum/react-developer-burger-ui-components";

const AppHeader = () => {
  return (
    <header className={styles.header}>
      <nav className={`${styles.menu} p-4`}>
        <div className={styles.menu_part_left}>
          {/*
          Надо исправить: элементы навигации в шапке должны быть ссылками <a>, а не 
          тег паразрафа
          А в следующих спринтах для навигации будут использоваться вместо ссылок
          компеоненты  Link и NavLink из библиотеку react-router
           */}
          <p href="/" className={`${styles.link} ${styles.link_active}`}>
            <BurgerIcon type="primary" />
            <p className="text text_type_main-default ml-2">Конструктор</p>
          </p>
          <p href="/feed" className={`${styles.link} ml-10`}>
            <ListIcon type="secondary" />
            <p className="text text_type_main-default ml-2">Лента заказов</p>
          </p>
        </div>
        <div className={styles.logo}>
          <Logo />
        </div>
        <p
          href="/profile"
          className={`${styles.link} ${styles.link_position_last}`}
        >
          <ProfileIcon type="secondary" />
          <p className="text text_type_main-default ml-2">Личный кабинет</p>
        </p>
      </nav>
    </header>
  );
};

export default AppHeader;
