import BurgerIngredient from "../burger-ingredient/burger-ingredient";
import styles from "./ingredients-category.module.css";

const IngredientsCategory = ({
  title,
  titleId,
  ingredients,
  onIngredientClick,
}) => {
  return (
    <>
      <h3 className="text text_type_main-medium mt-10 mb-6" id={titleId}>
        {title}
      </h3>
      <div className={styles.items}>
        {ingredients.map((ingredient) => {
          return (
            <BurgerIngredient
              ingredientData={ingredient}
              count={1}
              onClick={onIngredientClick}
            />
          );
        })}
      </div>
    </>
  );
};

export default IngredientsCategory;