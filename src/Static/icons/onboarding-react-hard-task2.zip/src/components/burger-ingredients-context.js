import React from 'react';

export const BurgerIngredientsContext = React.createContext();