import React, { useMemo, useContext } from "react";
import { Tab } from "@ya.praktikum/react-developer-burger-ui-components";
import IngredientsCategory from "../ingredients-category/ingredients-category";
import Modal from "../modal/modal";
import IngredientDetails from "../ingredient-details/ingredient-details";

import styles from "./burger-ingredients.module.css";
import { BurgerIngredientsContext } from "../burger-ingredients-context";
import { BurgerConstructorContext } from "../burger-constructor-context";

const BurgerIngredients = () => {
  const [currentTab, setCurrentTab] = React.useState("buns");
  const [ingredientInModal, setIngredientInModal] = React.useState(null);
  const closeIngredientModal = () => setIngredientInModal(null);

  const ingredients = useContext(BurgerIngredientsContext);
  const [, constructorDispatch] = useContext(BurgerConstructorContext);

  const onIngredientClick = (ingredient) => {
    setIngredientInModal(ingredient);
    constructorDispatch({
      type: 'ADD',
      payload: ingredient
    })
  };

  /* В можно лучше: скролл к разделу при клике на таб */
  const onTabClick = (tab) => {
    setCurrentTab(tab);
    const element = document.getElementById(tab);
    if (element) element.scrollIntoView({ behavior: "smooth" });
  };

  const buns = useMemo(
    () => ingredients.filter((item) => item.type === "bun"),
    [ingredients]
  );

  const mains = useMemo(
    () => ingredients.filter((item) => item.type === "main"),
    [ingredients]
  );

  const sauces = useMemo(
    () => ingredients.filter((item) => item.type === "sauce"),
    [ingredients]
  );

  return (
    <>
      <section className={styles.burger_ingredients}>
        <nav>
          <ul className={styles.menu}>
            <Tab
              value="buns"
              active={currentTab === "buns"}
              onClick={onTabClick}
            >
              Булки
            </Tab>
            <Tab
              value="mains"
              active={currentTab === "mains"}
              onClick={onTabClick}
            >
              Начинки
            </Tab>
            <Tab
              value="sauces"
              active={currentTab === "sauces"}
              onClick={onTabClick}
            >
              Соусы
            </Tab>
          </ul>
        </nav>
        <div className={styles.content}>
          <IngredientsCategory
            title="Булки"
            titleId="buns"
            ingredients={buns}
            onIngredientClick={onIngredientClick}
          />
          <IngredientsCategory
            title="Начинки"
            titleId="mains"
            ingredients={mains}
            onIngredientClick={onIngredientClick}
          />
          <IngredientsCategory
            title="Соусы"
            titleId="sauces"
            ingredients={sauces}
            onIngredientClick={onIngredientClick}
          />
        </div>
      </section>
      {ingredientInModal && (
        <Modal onClose={closeIngredientModal} title="Детали ингредиента">
          <IngredientDetails ingredientData={ingredientInModal} />
        </Modal>
      )}
    </>
  );
};

export default BurgerIngredients;
