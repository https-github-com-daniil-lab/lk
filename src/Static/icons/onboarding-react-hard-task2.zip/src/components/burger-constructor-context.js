import React from 'react';

export const BurgerConstructorContext = React.createContext();