import { useState, useContext, useMemo } from "react";
import {
  Button,
  ConstructorElement,
  CurrencyIcon,
  DragIcon,
} from "@ya.praktikum/react-developer-burger-ui-components";
import styles from "./burger-constructor.module.css";
import Modal from "../modal/modal";
import OrderDetails from "../order-details/order-details";
import { BurgerConstructorContext } from "../burger-constructor-context";
import { orderBurger } from "../../utils/burger-api";

const BurgerConstructor = () => {
  const [constructorItems, constructorDispatch] = useContext(
    BurgerConstructorContext
  );

  const [orderModalData, setOrderModalData] = useState(null);
  const onOrderClick = () => {
    if (!constructorItems.bun) return;

    orderBurger([
      constructorItems.bun._id,
      ...constructorItems.ingredients.map((ing) => ing._id),
      constructorItems.bun._id,
    ])
      .then((data) => {
        setOrderModalData(data);
        constructorDispatch({ type: "RESET" });
      })
      .catch((err) => {
        alert(`Ошибка при оформлении заказа: ${err.message}`);
      });
  };
  const closeOrderModal = () => setOrderModalData(null);

  const price = useMemo(() => {
    return (
      (constructorItems.bun ? constructorItems.bun.price * 2 : 0) +
      constructorItems.ingredients.reduce((s, v) => s + v.price, 0)
    );
  }, [constructorItems]);

  return (
    <section className={styles.burger_constructor}>
      {constructorItems.bun && (
        <div className={`${styles.element} mb-4 mr-4`}>
          <ConstructorElement
            type="top"
            isLocked={true}
            text={`${constructorItems.bun.name} (верх)`}
            price={constructorItems.bun.price}
            thumbnail={constructorItems.bun.image}
          />
        </div>
      )}
      <ul className={styles.elements}>
        {constructorItems.ingredients.map((item, index) => {
          return (
            <li className={`${styles.element} mb-4 mr-2`} key={index}>
              <DragIcon />
              <div className={`${styles.element_fullwidth} ml-2`}>
                <ConstructorElement
                  text={item.name}
                  price={item.price}
                  thumbnail={item.image}
                  handleClose={() =>
                    constructorDispatch({
                      type: "DELETE",
                      payload: index,
                    })
                  }
                />
              </div>
            </li>
          );
        })}
      </ul>
      {constructorItems.bun && (
        <div className={`${styles.element} mt-4 mr-4`}>
          <ConstructorElement
            type="bottom"
            isLocked={true}
            text={`${constructorItems.bun.name} (низ)`}
            price={constructorItems.bun.price}
            thumbnail={constructorItems.bun.image}
          />
        </div>
      )}
      <div className={`${styles.total} mt-10 mr-4`}>
        <div className={`${styles.cost} mr-10`}>
          <p className={`text ${styles.text} mr-2`}>{price}</p>
          <CurrencyIcon />
        </div>
        <Button
          type="primary"
          size="large"
          children="Оформить заказ"
          onClick={onOrderClick}
        />
      </div>
      {orderModalData && (
        <Modal onClose={closeOrderModal}>
          <OrderDetails orderNumber={orderModalData.order.number} />
        </Modal>
      )}
    </section>
  );
};

export default BurgerConstructor;
