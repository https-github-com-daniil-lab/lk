import styles from "./burger-ingredient.module.css";

import {
  Counter,
  CurrencyIcon,
} from "@ya.praktikum/react-developer-burger-ui-components";

const BurgerIngredient = ({ ingredientData, count, onClick }) => {
  const { image, price, name } = ingredientData;

  const handleClick = () => {
    onClick(ingredientData);
  };

  return (
    <article class={styles.article} onClick={handleClick}>
      {count && <Counter count={count} />}
      <img class={styles.img} src={image} alt="картинка ингредиента." />
      <div class={`${styles.cost} mt-2 mb-2`}>
        <p class="text text_type_digits-default mr-2">{price}</p>
        <CurrencyIcon />
      </div>
      <p class={`text text_type_main-default ${styles.text}`}>{name}</p>
    </article>
  );
};

export default BurgerIngredient;
