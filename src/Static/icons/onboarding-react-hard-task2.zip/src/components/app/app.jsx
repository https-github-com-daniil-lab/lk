import { useState, useEffect, useReducer } from "react";
import AppHeader from "../app-header/app-header";
import BurgerIngredients from "../burger-ingredients/burger-ingredients";
import BurgerConstructor from "../burger-constructor/burger-constructor";
import Preloader from "../preloader/preloader";
import styles from "./app.module.css";
import { BurgerConstructorContext } from "../burger-constructor-context";
import { BurgerIngredientsContext } from "../burger-ingredients-context";

import { getIngredients } from "../../utils/burger-api";


const constructorInitialState = {
  bun: null,
  ingredients: [],
};

const constructorReducer = (state, action) => {
  switch (action.type) {
    case "ADD":
      if (!state.bun && action.payload.type === "bun") {
        return {
          ...state,
          bun: action.payload,
        };
      }
      return {
        ...state,
        ingredients: [action.payload, ...state.ingredients],
      };
    case "DELETE":
      return {
        ...state,
        ingredients: [
          ...state.ingredients.slice(0, action.payload),
          ...state.ingredients.slice(action.payload + 1),
        ],
      };
    case "RESET":
      return {};
    default:
      return state;
  }
};

function App() {
  const [ingredients, setIngredients] = useState([]);

  const [ingredientsLoading, setIngredientsLoading] = useState(true);

  useEffect(() => {
    getIngredients()
      .then(setIngredients)
      .catch(() => alert("Во время загрузки ингредиентов произошла ошибка."))
      .finally(() => setIngredientsLoading(false));
  }, []);

  const constructorState = useReducer(
    constructorReducer,
    constructorInitialState
  );

  return (
    <div className={styles.app}>
      <AppHeader />
      {ingredientsLoading ? (
        <Preloader />
      ) : (
        <>
          <h1
            className={`${styles.title} text text_type_main-large mt-10 mb-5 pl-5`}
          >
            Соберите бургер
          </h1>
          <BurgerIngredientsContext.Provider value={ingredients}>
            <BurgerConstructorContext.Provider value={constructorState}>
              <main className={`${styles.main} pl-5 pr-5`}>
                <BurgerIngredients ingredients={ingredients} />
                <BurgerConstructor constructorIngredients={ingredients} />
              </main>
            </BurgerConstructorContext.Provider>
          </BurgerIngredientsContext.Provider>
        </>
      )}
    </div>
  );
}

export default App;
