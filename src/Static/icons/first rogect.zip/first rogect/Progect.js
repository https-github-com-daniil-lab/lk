var modal = document.getElementById('myModal');
var btn = document.getElementById("myBtn");
var btn1 = document.getElementById("myBtn1");
var btn2 = document.getElementById("myBtn2");
var span = document.getElementsByClassName("close")[0];


btn.onclick = function() {
    modal.style.display = "block";
}
btn1.onclick = function() {
    modal.style.display = "block";
}
btn2.onclick = function() {
    modal.style.display = "block";
}
span.onclick = function() {
    modal.style.display = "none";
}


window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function ColorWel(){
	let colorW = document.getElementById("welCol");
	let rand = Math.random() * 7;
    rand = Math.floor(rand);
    switch(rand){
case 0:colorW.style.color = "#c15cd6";break;
case 1:colorW.style.color = "#8c4299";break;
case 2:colorW.style.color = "#b83cab";break;
case 3:colorW.style.color = "#b2177e";break;
case 4:colorW.style.color = "pink";break;
case 5:colorW.style.color = "#9300b2";break;
case 6:colorW.style.color = "white";break;
default:colorW.style.color = "white";
    }
}