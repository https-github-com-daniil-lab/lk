import "../index.css"
function Header () {
    return (
        <header className="header page__header">
            <div className="header__image"></div>
        </header>
    )
}

export default Header;