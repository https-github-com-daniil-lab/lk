
function Footer () {
    
    return (
        <footer className="footer page__footer">
            <p className="footer__text">&copy; 2021 Mesto Russia</p>
        </footer>
    );
}

export default Footer;